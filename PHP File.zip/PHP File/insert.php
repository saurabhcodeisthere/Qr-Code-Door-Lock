<?php
	include "index.php";
	$fname=$_POST['fname'];
	$lname=$_POST["lname"];
	$email=$_POST["email"];
	$password=$_POST["pass"];
	$gender=$_POST["gender"];
	$date=$_POST["date"];
	$city=$_POST["city"];
	$state=$_POST["state"];
	$country=$_POST["country"];
	$contact=$_POST["contact"];
	$address=$_POST["address"];
	global $conn;
	if(isset($_POST['submit']))
	{
		$stmt = $conn->prepare("INSERT INTO details (Fname,Lname,Email,Password,Gender,Date,Address,City,State,Country,Phone) VALUES (?,?,?,?,?,?,?,?,?,?,?)");
		echo $conn -> error;
    	$stmt->bind_param("ssssssssssi",$fname,$lname,$email,$password,$gender,$date,$address,$city,$state,$country,$contact);
    	$stmt->execute();
    	$stmt->close();
	}
	else
	{
		echo "Data not reached.Enter again.";
	}
	if(isset($_POST['submit']))
	{
		$stmt = $conn->prepare("INSERT INTO login (Email,Password) VALUES (?, ?)");
    	$stmt->bind_param("ss",$email,$password);
    	$stmt->execute();
    	$stmt->close();
	}
	else
	{
		echo "Data not reached.Enter again.";
	}

?>