<?php
require('PHPMailer-master/src/PHPMailer.php');
require('PHPMailer-master/src/SMTP.php');

require('PHPMailer-master/src/Exception.php');

$mail = new PHPMailer\PHPMailer\PHPMailer();
$mail -> IsSMTP();

$mail->SMTPDebug = 4;
$mail->SMTPAuth = true;
$mail ->SMTPSecure='tls';
$mail ->Host='smtp.gmail.com';
$mail ->Port='587';
$mail-> isHTML();
$mail->Username='saurabh.2017@vitstudent.ac.in';
$mail->Password='saurabh12345';
$mail-> SetFrom('saurabh.2017@vitstudent.ac.in');
$mail->addAddress('saurabhmishrano1@gmail.com');
$mail->Subject='Sending mail';
$mail->Body='Hi! This is my first e-mail sending through php';
$file_to_attach = '../qrcode.png';
$mail->AddAttachment( $file_to_attach , 'Qr Code');
$mail->send()
?>