<?php
$to='vaibhavtiwarino1@gmail.com';
$subject='This is test message send through local host using php';
$message="<b>This is HTML message.</b>";
$message .="<h1>This is a headline message.</h1>";

$headers = "MIME-Version: 1.0" . "\r\n";
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";

// More headers
$headers .= 'From: <webmaster@example.com>' . "\r\n";
$headers .= 'Cc: myboss@example.com' . "\r\n";

mail($to,$subject,$message,$headers);
?>