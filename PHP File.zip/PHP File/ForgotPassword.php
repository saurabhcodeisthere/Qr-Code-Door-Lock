<?php
$con=mysqli_connect("localhost","root","","project");
session_start();

require('PHPMailer-master/src/PHPMailer.php');
     require('PHPMailer-master/src/SMTP.php');
     require('PHPMailer-master/src/Exception.php');
if($con)
{
    if($_SERVER["REQUEST_METHOD"]=="POST")
    {
      $uid = $_POST['userID'];
      $otp=rand(1000,9999);
      $subject='Forget/Reset Password OTP';
      $header='Content-type: text/html\r\n';
      $query = "SELECT 'email' WHERE 'UserId'='$uid'";
      echo "<h1>$query</h1>";
      if($data = mysqli_query($con,$query))
      {
        $data = mysqli_fetch_assoc($data);
        $email=$data['email'];
       $mail = new PHPMailer\PHPMailer\PHPMailer();
      $mail -> IsSMTP();
      $mail->SMTPDebug = 4;
      $mail->SMTPAuth = true;
      $mail ->SMTPSecure='tls';
      $mail ->Host='smtp.gmail.com';
      $mail ->Port='587';
      $mail-> isHTML();
      $mail->Username='********@***.ac.in';
      $mail->Password='************';
      $mail-> SetFrom('********@***.ac.in');
      $mail->addAddress($email);
      $mail->Subject='Sending mail';
      $mail->Body='Hi! This is my first e-mail sending through php';
      $mail->SMTPDebug = 0;
      $mail->send();        
      ?> <script>
                alert('Sucess');
                window.location = "OTP.php";
          </script>
          <?php
       } 
    }
  }
?>
<!DOCTYPE html>
  <html lang="en" dir="ltr">

  <head>
    <meta charset="utf-8">
    <title>Forgot Password</title>

    <link rel="stylesheet" type="text/css" href="../css/forgetpassword.css" />
    <link rel="stylesheet" type="text/css" href="../css/Genral.css" />
    <link rel="stylesheet" href="../css/headPart2.css">
    <script type="text/javascript" src="..\js\headPart.js">   </script>
  </head>

  <body onload="startTime()">
    <!-- navMenu for navigation bar -->
        <input type="image" id="navMenuWrapper" name="" value=""  onclick="hide_show_navMenu()" src="../Res/home_Icon.png">
        <div id="navMenu">
              <ul>
                <li class="navManuListElement"><a>ba</a></li>
                <li class="navManuListElement"><a href="FeedPage.html">Home</a></li>
                <li class="navManuListElement"><a href="myBooks_page.html">My Books</a></li>
                <li class="dropdown navManuListElement">
                  <a href="javascript:void(0)" class="dropbtn">Browse</a>
                  <div id="navMenuDropdown">
                    <a href="#">Fantasy</a>
                    <a href="#">Sci-Fi</a>
                    <a href="#">Biographies</a>
                  </div>
                </li>
                <li> <input type="search" name="" value="" placeholder="Search . . . "><input type="image" name="" value="" src="../Res/mag.png"></li>
              </ul>
        </div>

    <div class="Login" style="width: 500px; height: 370px;">
         <img src="../Res/avatar.png" class="avatar">
         <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="post">
        <h2> Forgot/Reset Passsword</h2>
        <p>Username :</p>
        <input id="logId" type="text" name="userID" value="">
        <input type="submit" name="Submit" value="Submit">

      </form>
  </div>
  </body>

  </html>
